import os
import tkinter
from tkinter import filedialog
from tkinter import messagebox
import tkinter.ttk
import time
from datetime import datetime
from tkinter import *
from tkinter import ttk
import zipfile
#import PyPDF2
import stat

command = 'powershell.exe -window hidden -ExecutionPolicy Bypass -File ./get_os_info.ps1 '
os.system(command)

command = 'powershell.exe -window hidden -ExecutionPolicy Bypass -File ./check_Account.ps1 '
os.system(command)

command = 'powershell.exe -window hidden -ExecutionPolicy Bypass -File ./check_Secure.ps1 '
os.system(command)
