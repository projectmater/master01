$env:LC_ALL='C.UTF-8'
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function Test-Role 
{
  Param( [Security.Principal.WindowsBuiltinRole]$Role )

  $CurrentUser = [Security.Principal.WindowsPrincipal]([Security.Principal.WindowsIdentity]::GetCurrent())

  $CurrentUser.IsInRole($Role)
}

# 공백 / 줄바꿈이 존재하는 object형 결과값을 공백없는 String형 결과값으로 바꿔주는 함
function String([object]$string)
{
    $string_return = Out-String -InputObject $string
    $string_return = $string_return.Split(" ")[0]
    $string_return = $string_return.Split("`r")[2]
    $string_return = $string_return.Split("`n")[1]

    return $string_return
}

# 경로의 권한을 얻어온다.
function Get-Permissions($Path)
{
    (Get-Acl -Path $Path).Access | Select-Object 
    @{Label="identity"; Expression={$_.IdentityReference}}
}

# 레지스트리 키 이름, 타입, 값을 출력해준다.
function Get-RegistryValue
{
    param
    (
        [Parameter(Mandatory = $true)]
        $RegistryKey
    )

    $key = Get-Item -Path "Registry::$RegistryKey"
    $key.GetValueNames() |
    ForEach-Object {
        $name = $_
        $rv = 1 | Select-Object -Property Name, Type, Value
        $rv.Name = $name
        $rv.Type = $key.GetValueKind($name)
        $rv.Value = $key.GetValue($name)
        $rv
  
    }
}

# 입력된 경로의 레지스트리 키가 존재하는지 확인한다.
function Test-RegistryValue($regkey, $name) 
{
    try
    {
        $exists = Get-ItemProperty $regkey $name -ErrorAction SilentlyContinue
        if (($null -eq $exists) -or ($exists.Length -eq 0))
        {
            return $false
        }
        else
        {
            return $true
        }
    }
    catch
    {
        return $false
    }
}

#SID를 계정이름으로 변경해준다.
function Convert_SID_TO_USERNAME($SID)
{
    $objSID = New-Object System.Security.Principal.SecurityIdentifier($SID)
    $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
    return ($objUser.Value)
}

#관리자 계정으로 점검하는지 확인

$Current = Test-Role "Administrator"
#if(!$Current)
#{
#    exit 5
#}

# 검사에 필요한 명령문을 사용하기 위한 Module Import
$Use_Module_List = @("WebAdministration","ActiveDirectory","DnsServer","PSWindowsUpdate")

#모듈 설정
foreach($module_item in $Use_Module_List)
{
    if((Get-Module -Name $module_item).count -ne 0)
    {

        try
        {
            # 모듈을 사용한다.
            Import-Module -Name $module_item -Force
        }
        catch
        {
            # 만약 사용할 모듈이 설치되어 있지 않다면 해당 모듈을 설치한다.
            Install-Module -Name $module_item -Force 
        }
    }
}

SecEdit /export /cfg ./user_rights

try{
    $Active_DIR_Service = Get-ADDefaultDomainPasswordPolicy
}
catch {
    $Active_DIR_Service = 0
}

###### 1. Administrator 계정 이름 바꾸기 ######   
$RV = 'Whether to change the administrator account name'
$importance = 'MAJOR'

try{
    $var = (Get-LocalUser Administrator).length
}
catch{
    
}

if($var -gt 0)
{
    $result = 'BAD'

    $CV = "Administrator"
}
else
{
    $result = 'GOOD'

    $f1 = (Get-LocalGroupMember -Name 'Administrators').Name
    $f1 = Out-String -InputObject $f1
    $f1 = $f1.Split("\")
    $CV = $f1[-1]
}

Write-Host ':::: window vulnerablility check program :::' > ./result_account.txt
Write-Output 1:Importance:$importance >> ./result_account.txt
Write-Output 1:Result:$result >> ./result_account.txt
Write-Output 1:Value:$CV >> ./result_account.txt

############# 2. Guest 계정 상태 ##############
$RV = "Guest account disable"
$importance = "MAJOR"

$var = Get-LocalUser -Name Guest | Select-Object Enabled | Format-Wide

if($var -eq 'True')
{
    $result = "BAD"

    $CV = "Enable Guest Account"
}
else
{
    $result = "GOOD"

    $CV = "Disable Guest Account"
}

Write-Output 2:Importance:$importance >> ./result_account.txt
Write-Output 2:Result:$result >> ./result_account.txt
Write-Output 2:Value:$CV >> ./result_account.txt

########### 3. 계정 잠금 임계값 설정 ###########
#$RV = "under 5"
$importance = "MAJOR"

$tempStr = Get-Content user_rights | Select-String "LockoutBadCount"
#$tempStr = Select-String "LockoutBadCount"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]

if($count)
{
    if($count -eq 0)
    {
        $result = "BAD"
        $CV = $count
        $CV = $CV.Trim()
        #$CV = "Account lockout threshold not set"
    }
    elseif($count -le 5)
    {
        $result = "GOOD"
        $CV = $count
        $CV = $CV.Trim()       
        #$CV = "The current account lockout threshold is " + $CV + "times"
    }
    elseif($count -ge 6)
    {
        $result = "BAD"
        $CV = $count
        $CV = $CV.Trim()
        #$CV = "The current account lockout threshold is " + $CV + "times"
    }
}
else
{
    $result = "BAD"
    $CV = "NOT" #"The account lockout threshold is not set."
}

Write-Output 3:Importance:$importance >> ./result_account.txt
Write-Output 3:Result:$result >> ./result_account.txt
Write-Output 3:Value:$CV >> ./result_account.txt

###### 4. 해독 가능한 암호화를 사용하여 암호 저장 해제 ######

#$title="Store passwords using reversible encryption"

$RV = "Not used"
$importance = "MAJOR"

$tempStr = Get-Content user_rights | Select-String "PasswordComplexity"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]


if($count)
{
    $result = "BAD"
    $CV = "YES" #"해당 옵션 사용 중"
}
else
{
    $result = "GOOD" #"양호"
    $CV = "NO" #"해당 옵션 사용 안 함"
}

Write-Output 4:Importance:$importance >> ./result_account.txt
Write-Output 4:Result:$result >> ./result_account.txt
Write-Output 4:Value:$CV >> ./result_account.txt

###### 46. Everyone 사용권한을 익명사용자에 적용 해제 ######

#$title="Let Everyone permissions apply to anonymous users"

#$RV = "사용 안 함"
$importance = "MIDDLE" #"중"

$RegPath = "HKLM:SYSTEM\CurrentControlSet\Control\Lsa"
#$RegPath = "HKLM:SYSTEM\CurrentSet1\Control\Lsa"
$Name = "everyoneincludesanonymous"

$var = Get-ItemPropertyValue -Path $RegPath -Name $Name

if(!$var)
{
    $result = "GOOD" #"양호"
    $CV = "YES" #"Everyone 사용권한을 익명사용자에 적용 해제" 미사용중
}
else
{
    $result = "취약"
    $CV = "NO" #"Everyone 사용권한을 익명사용자에 적용"
}

Write-Output 5:Importance:$importance >> ./result_account.txt
Write-Output 5:Result:$result >> ./result_account.txt
Write-Output 5:Value:$CV >> ./result_account.txt

########### 47. 계정 잠금 기간 설정 (60분 이상 GOOD) ###########
#$title="Account lockout duration"

#$RV = "60(분)이상"
$importance = "MIDDLE" #"중"

$tempStr = Get-Content user_rights | Select-String "LockoutDuration"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]

if($count)
{
    if($count -ge 60)
    {
        $result = "GOOD" #"양호"
        $CV = $count.ToString() # + "분"
    }
    else
    {
        $result = "BAD" #"취약"
        $CV = $count.ToString() # + "분"
    }
}
else
{
    $result = "BAD" # "취약"
    $CV = "NOT" #"값이 설정되어 있지 않습니다."
}

# 1) Get-ADDefaultDomainPasswordPolicy 명령어를 입력한다
# 2) LockoutDuration , LockoutObsercationWindow 값을 확인 한다
Write-Output 6:Importance:$importance >> ./result_account.txt
Write-Output 6:Result:$result >> ./result_account.txt
Write-Output 6:Value:$CV >> ./result_account.txt

########### 48. 패스워드 복잡성 설정 ##########
$title="Password must meet complexity requirements"

#$RV = "사용"
$importance = "MIDDLE" #"중"

$tempStr = Get-Content user_rights | Select-String "PasswordComplexity"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]

if($count)
{
    $result = "GOOD" #"양호"
    $CV = "YES" #"해당 옵션 사용 중"
}
else
{
    $result = "BAD" #"취약"
    $CV = "NO" #"해당 옵션 사용 안 함"
}

Write-Output 7:Importance:$importance >> ./result_account.txt
Write-Output 7:Result:$result >> ./result_account.txt
Write-Output 7:Value:$CV >> ./result_account.txt

######## 49. 패스워드 최소 암호 길이 ##########
#$title="Minimum password length"

#$RV = "8(자)이상"
$importance = "MIDDLE" #"중"

$tempStr = Get-Content user_rights | Select-String "MinimumPasswordLength"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]

if($count)
{
    if($count -ge 8)
    {
        $result = "GOOD" #"양호"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "자"
    }
    else
    {
        $result = "BAD" #"취약"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "자"
    }
}
else
{
    $result = "BAD" #"취약"
    $CV = "NOT" #"해당 옵션이 설정되어 있지 않습니다."
}

Write-Output 8:Importance:$importance >> ./result_account.txt
Write-Output 8:Result:$result >> ./result_account.txt
Write-Output 8:Value:$CV >> ./result_account.txt

######### 50. 패스워드 최대 사용 기간 (90일 이하 설정 적정) #########
$title="Maximum password age"

#$RV = "90(일)이하"
$importance = "MIDDLE" #"중"

$tempStr = Get-Content user_rights | Select-String "MaximumPasswordAge = "
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1].Trim()

if($count)
{
    if($count -le 90)
    {
        $result = "GOOD" #"양호"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "일"
    }
    else
    {
        $result = "BAD" #"취약"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "일"
    }
}
else
{
    $result = "BAD" #"취약"
    $CV = "NOT" #"해당 옵션이 설정되어 있지 않습니다."
}

# 1) Get-ADDefaultDomainPasswordPolicy 명령어를 입력한다
# 2) MaxPasswordAge 값을 확인한다

Write-Output 9:Importance:$importance >> ./result_account.txt
Write-Output 9:Result:$result >> ./result_account.txt
Write-Output 9:Value:$CV >> ./result_account.txt

######### 51. 패스워드 최소 사용 기간 (0보다 큰 값 입력 적정) #########
#$title="Minimum password age"

#$RV = "0보다 큰 값"
$importance = "MIDDLE" #"중"

$tempStr = Get-Content user_rights | Select-String "MinimumPasswordAge"
$tempStr = Out-String -InputObject $tempStr
$tempStr = $tempStr.Split('=')
$count = $tempStr[-1]

if($count)
{
    if($count -gt 0)
    {
        $result = "GOOD" #"양호"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "일"
    }
    else
    {
        $result = "BAD" #"취약"
        $CV = $count
        $CV = $CV.Trim()
        #$CV += "일"
    }
}
else
{
    $result = "BAD" #"취약"
    $CV = "NOT" #"설정X" 설정되지 않음
}

Write-Output 10:Importance:$importance >> ./result_account.txt
Write-Output 10:Result:$result >> ./result_account.txt
Write-Output 10:Value:$CV >> ./result_account.txt