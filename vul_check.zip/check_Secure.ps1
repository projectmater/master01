function Test-Role 
{
  Param( [Security.Principal.WindowsBuiltinRole]$Role )

  $CurrentUser = [Security.Principal.WindowsPrincipal]([Security.Principal.WindowsIdentity]::GetCurrent())

  $CurrentUser.IsInRole($Role)
}

# 공백 / 줄바꿈이 존재하는 object형 결과값을 공백없는 String형 결과값으로 바꿔주는 함
function String([object]$string)
{
    $string_return = Out-String -InputObject $string
    $string_return = $string_return.Split(" ")[0]
    $string_return = $string_return.Split("`r")[2]
    $string_return = $string_return.Split("`n")[1]

    return $string_return
}

# 경로의 권한을 얻어온다.
function Get-Permissions($Path)
{
    (Get-Acl -Path $Path).Access | Select-Object
    @{Label="identity"; Expression={$_.IdentityReference}}
}

# 레지스트리 키 이름, 타입, 값을 출력해준다.
function Get-RegistryValue
{
    param
    (
        [Parameter(Mandatory = $true)]
        $RegistryKey
    )

    $key = Get-Item -Path "Registry::$RegistryKey"
    $key.GetValueNames() |
    ForEach-Object {
        $name = $_
        $rv = 1 | Select-Object -Property Name, Type, Value
        $rv.Name = $name
        $rv.Type = $key.GetValueKind($name)
        $rv.Value = $key.GetValue($name)
        $rv
  
    }
}

# 입력된 경로의 레지스트리 키가 존재하는지 확인한다.
function Test-RegistryValue($regkey, $name) 
{
    try
    {
        $exists = Get-ItemProperty $regkey $name -ErrorAction SilentlyContinue
        if (($null -eq $exists) -or ($exists.Length -eq 0))
        {
            return $false
        }
        else
        {
            return $true
        }
    }
    catch
    {
        return $false
    }
}

#SID를 계정이름으로 변경해준다.
function Convert_SID_TO_USERNAME($SID)
{
    $objSID = New-Object System.Security.Principal.SecurityIdentifier($SID)
    $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
    return ($objUser.Value)
}


###### 7. 공유 권한 및 사용자 그룹 설정 ######
#$title="공유 권한 및 사용자 그룹 설정"

#$RV = "일반 공유 디렉토리 X / 접근 권한에 Everyone 권한이 없음"
$importance = "MAJOR" #"상"

# 모든 공유 폴더 중 Everyone으로 공유 된 폴더 정보를 조회
$SmbShareInfo = Get-SmbShare | ForEach-Object {Get-SmbShareAccess -Name $_.Name} | Where-Object {$_.AccountName -like 'Everyone'}

$temp = $SmbShareInfo.Name  # 수정(위치이동)
$var = $temp.Length

#$var = $SmbShareInfo.Length
$CV = @()

#$temp = $SmbShareInfo.Name

if($var -gt 0)
{
    $result = "BAD" #"취약"
    $i = 1
    foreach($item in $temp)
    {
        #$CV += ($item + ',')
        $CV += $item
        if($temp.length -gt $i)
        {
            $CV += ','
            $i += 1
        }

    }
    #$CV[-1] = "Everyone" #"공유 폴더가 Everyone 권한으로 공유 중"
}
else
{
    $result = "GOOD" #"양호"
    $CV = "NOT" #"존재X"
}

Write-Output 1:Importance:$importance > ./result_secure.txt
Write-Output 1:Result:$result >> ./result_secure.txt
Write-Output 1:Value:$CV >> ./result_secure.txt


###### 8. 하드디스크 기본 공유 제거 취약 ######
#$index="08"
#$title="하드디스크 기본 공유 제거 취약"

#$RV = "AutoShareServer 값이 0 & 기본 공유가 존재X"
$importance = "MAJOR" #"상"

# IPC$를 제외한 기본 공유 폴더가 존재하는지 확인
$DefaultSmbInfo = Get-SmbShare | Where-Object {$_.Name -ne "IPC$"} |Where-Object {$_.Name -like "*$"}
$var = $DefaultSmbInfo.Length

$RegPath = "HKLM:SYSTEM\CurrentControlSet\Services\LanmanServer\AutotunedParameters"
$Name = "AutoShareServer"

try{
    $REGvar = Get-ItemPropertyValue -Path $RegPath -Name $Name
}
catch
{
}

if($var -gt 0)
{
    $result = "BAD" #"취약"
    $CV = "YES, " #"기본 공유 폴더가 존재하며, "
}
else
{
    $result = "GOOD" #"양호"
    $CV = "NO" #"기본 공유 폴더가 존재하지 않으며, "
}

if($REGvar -eq 0)
{
    $CV += "AutoShareServer=0" #"AutoShareServer 값은 0"
}
elseif($REGvar -eq 1)
{
    $result = "BAD" #"취약"
    $CV += "AutoShareServer=1" #"AutoShareServer 값은 1"
}
else
{
    $result = "BAD" #"취약"
    $CV += "NOT" #"AutoShareServer 값 설정X"
}

Write-Output 2:Importance:$importance >> ./result_secure.txt
Write-Output 2:Result:$result >> ./result_secure.txt
Write-Output 2:Value:$CV >> ./result_secure.txt


########### 9. 불필요한 서비스 제거 ###########
#$index="09"
#$title="불필요한 서비스 제거"

#$RV = "일반적으로 불필요한 서비스들을 중지"
$importance = "MAJOR" #"상"

# 일반적으로 불필요한 서비스 목록 (KISA 문서 참고)
$Needless_Services = @("Alerter","Automatic Updates","Clipbook","Computer Browser","Cryptographic Services","DHCP Client",
"Distributed Link Tracking","DNS Client","Error reporting Service","Human Interface Device Access","IMAPU CD-Buming COM Service",
"Messenger","NetMeeting Remote Desktop Sharing","Portable Media Serial Number","Print Spooler","Remote Registry","Simple TCP/IP Services",
"Wireless Zero Configuration")

$count = 0
$tempSTR = @()
 
foreach($item in $Needless_Services)
{
    Write-Output ($item) >> Needless_Services_list.txt    
    $var = Get-Service | Where-Object {$_.Status -eq 'Running'} | Where-Object {$_.DisplayName -like $item} | Format-List
    if($var.length -gt 0)
    {
        $tempSTR += $item
        $tempSTR += ','

        $count++
    }
}
if($tempSTR.count -gt 0)
{
    $tempSTR[-1] = ''
}

if($count -gt 0)
{
    $result = "BAD" #"취약"
    $CV = $tempSTR #"구동중인 불필요한 서비스의 목록은 " + $tempSTR
}
else 
{
    $result = "GOOD" #"양호"
    $CV = "NOT" #"구동중인 불필요한 서비스가 존재하지 않습니다."
}

Write-Output 3:Importance:$importance >> ./result_secure.txt
Write-Output 3:Result:$result >> ./result_secure.txt
Write-Output 3:Value:$CV >> ./result_secure.txt


########### 37. SAM 파일 접근 통제 설정 ###########
#$title = "Restrict clients allowed to make remote calls to SAM"

#$RV = "SAM 파일 접근 권한에 Administrator , System 그룹만 모든 권한으로 설정되어 있는 경우"
$importance = "MAJOR" #"상"

$tempSTR = @()

$Access_sam = (Get-Permissions -Path "C:\Windows\System32\config\SAM").IdentityReference
$Count = 0

foreach($Nameitem in $Access_sam)
{
    $tempSTR += $Nameitem
    $tempSTR += ','

    if(!($Nameitem -like "*SYSTEM*" -or $Nameitem -like "*Administrator*"))
    {
        $Count++    
    }
}

if($tempSTR.count -gt 0)
{
    $tempSTR[-1] = ''
}

if($Count -eq 0)
{
    $result = "GOOD" #"양호"
    $CV = "YES" #"SAM 파일의 권한이 SYSTEM / Administrator 계정에만 부여되어 있습니다."
}
else
{
    $result = "BAD" #"취약"
    $CV = "NO" #"SAM 파일에 권한이 존재하는 그룹 / 사용자는 " + $tempSTR + " 입니다."
}

Write-Output 4:Importance:$importance >> ./result_secure.txt
Write-Output 4:Result:$result >> ./result_secure.txt
Write-Output 4:Value:$CV >> ./result_secure.txt

########### 38. 화면보호기 설정 (대기 시간 10분 이하 설정 적정)###########
#$title = "ScreenSaveActive" #"화면보호기 설정"

#$RV = "화면 보호기 설정 & 대기 시간 10분 이하 값 & 화면 보호기 해제를 위한 암호 사용 시"
$importance = "MAJOR" #"상"

$Timeout = (Get-RegistryValue "HKCU\Control Panel\Desktop\" | Where-Object {$_.Name -like "*ScreenSaveTimeOut*"}).Value
$Secure = (Get-RegistryValue "HKCU\Control Panel\Desktop\" | Where-Object {$_.Name -like "*ScreenSaveActive*"}).Value

if(($Timeout / 60) -le 10 -and $Secure -eq 1)
{
    $result = "GOOD" #"양호"
    $CV = ($Timeout / 60) #"화면 보호기 설정 O / 해제시 비밀번호 요청 O / 현재 대기 시간" + ($Timeout / 60).toString() + "분 입니다."
}
elseif($null -eq $Timeout -and $null -eq $Secure)
{
    $result = "BAD" #"취약"
    $CV = "CODE1" #"화면 보호기가 기본 옵션으로 설정되어 있습니다."
}
else
{
    if(($Timeout / 60) -gt 10)
    {
        $result = "BAD" #"취약"
        $CV = ($Timeout / 60) #"화면 보호기 설정O / 현재 대기 시간" + ($Timeout / 60).toString() + "분 입니다."
    }
    if($Secure -eq 0)
    {
        $result = "BAD" #"취약"
        $CV = "CODE2" #"화면 보호기 설정O / 해제시 비밀번호 요청 X"
    }
}

Write-Output 5:Importance:$importance >> ./result_secure.txt
Write-Output 5:Result:$result >> ./result_secure.txt
Write-Output 5:Value:$CV >> ./result_secure.txt

########### 39. 로그온 하지 않고 시스템 종료 허용 해제 ###########
#$title="로그온 하지 않고 시스템 종료 허용 해제"

#$RV = "'사용 안함' 옵션으로 설정"
$importance = "MAJOR" #"상"

$flag = (Get-RegistryValue "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" | Where-Object {$_.Name -eq "shutdownwithoutlogon"})

if($flag -eq 0)
{
    $result = "GOOD" #"양호"
    $CV = "YES" #"로그온 하지 않고 시스템 종료가 허용되지 않습니다."
}
else
{
    $result = "BAD" #"취약"
    $CV = "NO" #"로그온 하지 않고 시스템 종료가 허용됩니다."   
}

Write-Output 6:Importance:$importance >> ./result_secure.txt
Write-Output 6:Result:$result >> ./result_secure.txt
Write-Output 6:Value:$CV >> ./result_secure.txt

########### 40. 원격 시스템에서 강제로 시스템 종료 ###########
#$title="원격 시스템에서 강제로 시스템 종료"

#$RV = "해당 정책에 'Administrator'만 존재하는 경우"
$importance = "MAJOR" #"상"

$tempSTR = @()

$String_1 = Get-Content -Path ./user_rights | select-string -Pattern "SeRemoteShutdownPrivilege"
$String_1 = Out-String -InputObject $String_1

$String_1 = $String_1 -replace "`\s+",''

$String_2 = $String_1.Split("*,")
$SID_List = @()
$count = 0
for($X=1;$X -lt $String_2.count;$X++)
{
    if($String_2[$X].length -ne 0)
    {
        $SID_List += $String_2[$X]
    }
}

foreach($SID_ITEM in $SID_List)
{
    $flag = Convert_SID_TO_USERNAME $SID_ITEM

    $tempSTR += $flag
    $tempSTR += ','

    if(!($flag -like "*Administrator*"))
    {
        $count++
    }
}

if($tempSTR.count -gt 0)
{
    $tempSTR[-1] = ''
}


if($count -eq 0)
{
    $result = "GOOD" #"양호"
    $CV = "Administrator" #"원격 시스템에서 강제로 시스템 종료 가능 정책에 Administrator 계정만 포함되어 있습니다."
}
else
{
    $result = "BAD" #"취약"
    $CV = $tempSTR #$tempSTR + " 계정들이 원격 시스템에서 강제로 시스템 종료 가능 정책에 포함되어 있습니다."
}

Write-Output 7:Importance:$importance >> ./result_secure.txt
Write-Output 7:Result:$result >> ./result_secure.txt
Write-Output 7:Value:$CV >> ./result_secure.txt

########### 43. Autologin 기능 제어 ###########
#$title="Autologin 기능 제어"

#$RV = "AutoAdminLogon 값이 없거나 0으로 설정되어 있는 경우"
$importance = "MAJOR" #"상"

$flag = Test-RegistryValue "HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Winlogon" "AutoAdminLogon"

if($flag)
{
    $flag = (Get-RegistryValue "HKLM\SOFTWARE\Microsoft\WindowsNT\CurrentVersion\Winlogin" | Where-Object {$_.Name -eq "AutoAdminLogon"}).Value
    
    if($flag -eq 1)
    {
        $result = "BAD" #"취약"
        $CV = "YES" #"AutoAdminLogon 기능을 사용하는 중입니다."
    }
    else
    {
        $result = "GOOD" #"양호"
        $CV = "NO" #"AutoAdminLogon 기능을 사용하지 않습니다."
    }
}
else
{
    $result = "GOOD" #"양호"
    $CV = "NO" #"AutoAdminLogon 기능을 사용하지 않습니다."
}

Write-Output 8:Importance:$importance >> ./result_secure.txt
Write-Output 8:Result:$result >> ./result_secure.txt
Write-Output 8:Value:$CV >> ./result_secure.txt

########### 44.이동식 미디어 포맷 및 꺼내기 허용 ###########
#$title="이동식 미디어 포맷 및 꺼내기 허용"

#$RV = "해당 옵션 정책이 'Administrator' 로 설정되어 있는 경우"
$importance = "MAJOR" #"상"

$flag = Test-RegistryValue "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" "AllocateDASD"

if($flag)
{
    $flag = (Get-RegistryValue "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" | Where-Object {$_.Name -eq "AllocateDASD"}).Value
    
    if($flag -eq 0)
    {
        $result = "GOOD" #"양호"
        $CV = "Administrator"
    }
    elseif($flag -eq 1)
    {
        $result = "BAD1" #"취약"
        $CV = "Administrator, Power Users" #"Administrator 및 Power Users"
    }
    elseif($flag -eq 2)
    {
        $result = "BAD2" #"취약"
        $CV = "Administrator, Interactive Users" #"Administrator 및 Interactive Users"
    }
}
else
{
    $result = "BAD3" #"취약"
    $CV = "NOT" #"'이동식 미디어 포맷 및 꺼내기 허용' 옵션의 설정값을 지정하지 않았습니다."
}

Write-Output 9:Importance:$importance >> ./result_secure.txt
Write-Output 9:Result:$result >> ./result_secure.txt
Write-Output 9:Value:$CV >> ./result_secure.txt
