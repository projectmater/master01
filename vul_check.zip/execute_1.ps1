
Invoke-Command -FilePath C:\Python\vul_check\get_os_info.ps1
Invoke-Command -FilePath .\check_Account1.ps1
Write-Output "Hello"